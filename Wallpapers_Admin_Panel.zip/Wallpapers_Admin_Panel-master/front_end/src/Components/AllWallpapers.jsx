import React from 'react'

function AllWallpapers() {
 
  return (
    <div>AllWallpapers</div>
  )
}

export default AllWallpapers