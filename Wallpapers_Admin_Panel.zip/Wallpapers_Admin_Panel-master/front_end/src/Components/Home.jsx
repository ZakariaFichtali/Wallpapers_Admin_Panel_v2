import React from 'react'
import '../CSS/App.css'
import {useNavigate } from "react-router-dom";

// -------------------------------------------------------------------
function Home() {
    const navigate = useNavigate()
    const GoAllWallpapers = () => {
      navigate('/wallpapers')
    
    }
  return (
    <div className='all'>    
     {/* ------------------------------    card 1  ---------------------------------- */}
        <div className="card" style={{ width: "24rem" }}>
              <img src="..." className="card-img-top" alt="..." />
            <div className="card-body">
              <h5 className="card-title">All Wallpaper</h5>
                  <p className="card-text">
                    Some quick example text to build on the card title and make up the bulk of
                    the card's content.
                  </p>
              <button onClick={GoAllWallpapers}>Wallpapers</button>
    
            </div>
         </div>
     {/* --------------------------------------------------------------------------- */}
      {/* ------------------------------    card 2  ---------------------------------- */}
      <div className="card" style={{ width: "24rem" }}>
              <img src="..." className="card-img-top" alt="..." />
            <div className="card-body">
              <h5 className="card-title">All Wallpaper</h5>
                  <p className="card-text">
                    Some quick example text to build on the card title and make up the bulk of
                    the card's content.
                  </p>
              <button onClick={GoAllWallpapers}>Wallpapers</button>
    
            </div>
         </div>
     {/* --------------------------------------------------------------------------- */}
      {/* ------------------------------    card 3  ---------------------------------- */}
      <div className="card" style={{ width: "24rem" }}>
              <img src="..." className="card-img-top" alt="..." />
            <div className="card-body">
              <h5 className="card-title">All Wallpaper</h5>
                  <p className="card-text">
                    Some quick example text to build on the card title and make up the bulk of
                    the card's content.
                  </p>
              <button onClick={GoAllWallpapers}>Wallpapers</button>
    
            </div>
         </div>
     {/* --------------------------------------------------------------------------- */}
     {/* --------------------------------------------------------------------------- */}
     {/* ------------------------------    card 4  --------------------------------- */}
      <div className="card" style={{ width: "24rem" }}>
              <img src="..." className="card-img-top" alt="..." />
            <div className="card-body">
              <h5 className="card-title">All Wallpaper</h5>
                  <p className="card-text">
                    Some quick example text to build on the card title and make up the bulk of
                    the card's content.
                  </p>
              <button onClick={GoAllWallpapers}>Wallpapers</button>
    
            </div>
         </div>
     {/* --------------------------------------------------------------------------- */}
      {/* ------------------------------    card 5  --------------------------------- */}
      <div className="card" style={{ width: "24rem" }}>
              <img src="..." className="card-img-top" alt="..." />
            <div className="card-body">
              <h5 className="card-title">All Wallpaper</h5>
                  <p className="card-text">
                    Some quick example text to build on the card title and make up the bulk of
                    the card's content.
                  </p>
              <button onClick={GoAllWallpapers}>Wallpapers</button>
    
            </div>
         </div>
     {/* --------------------------------------------------------------------------- */}
      {/* ------------------------------    card 6  --------------------------------- */}
      <div className="card" style={{ width: "24rem" }}>
              <img src="..." className="card-img-top" alt="..." />
            <div className="card-body">
              <h5 className="card-title">All Wallpaper</h5>
                  <p className="card-text">
                    Some quick example text to build on the card title and make up the bulk of
                    the card's content.
                  </p>
              <button onClick={GoAllWallpapers}>Wallpapers</button>
    
            </div>
         </div>
     {/* --------------------------------------------------------------------------- */}
        
    </div>
  )
}

export default Home